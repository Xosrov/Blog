-- "Subtitler (lite).lua" -- VLC Extension for VLC-2.0.x

--[[
INSTALLATION:
Put the file in the VLC subdir /lua/extensions, by default:
* Windows (all users): %ProgramFiles%\VideoLAN\VLC\lua\extensions\
* Windows (current user): %APPDATA%\VLC\lua\extensions\
* Linux (all users): /usr/share/vlc/lua/extensions/
* Linux (current user): ~/.local/share/vlc/lua/extensions/
* Mac OS X (all users): /Applications/VLC.app/Contents/MacOS/share/lua/extensions/
(create directories if they don't exist)
Restart the VLC.
USAGE:
Then you simply use the extension by going to the "View" menu and selecting it there.

Forum location: http://forum.videolan.org/viewtopic.php?f=29&t=97791
--]]

-- Global variables:
subtitles_path = nil  -- means automatic detection. For example "film.avi" looks for "film.srt" in the same directory.
--subtitles_path = "D:/films/subtitles.srt"  -- fixed subtitle file. The path must contain only English characters!
output_osd = true  -- true / false
output_dialogbox = true
html1 = "<div align=\"center\" style=\"background-color:white;\"><a style=\"font-family:Verdana;font-size:36px;font-weight:bold;color:black;background-color:white;\">"
html2 = "</a></div>"
welcome = "Subtitler (lite)"
charset = "Windows-1250"  -- Use proper codepage of your subtitles! ("ISO-8859-2", "cp852", ... )
--charset = nil  -- means default UTF-8 encoding!
osd_position = "top"


function descriptor()
	return {
		title = "Subtitler (lite)",
		version = "1.0";
		author = "lubozle";
		url = 'http://addons.videolan.org/content/show.php?content=152364';
		shortdesc = "Subtitles displayer";
		description = "<div style=\"background-color:lightgreen;\"><b>Subtitler (lite)</b> is VLC extension (extension script \"Subtitler (lite).lua\") that displays subtitles on the screen in a playing video and/or in a dialog box. Now you can watch your film with 2 different subtitles.</div>";
		capabilities = {"input-listener"}
	}
end
function activate()
	create_dialog()
	input_callback("add")
end
function deactivate()
	input_callback("del")
end
function close()
		vlc.deactivate()
end
function input_changed()
	input_callback("toggle")
end

function create_dialog()
	dlg = vlc.dialog("Subtitler (lite)")
	w1 = dlg:add_label(html1..welcome..html2, 1, 1, 1, 1)
end
function dialogbox_label(label_text)
	dlg:del_widget(w1)
	w1 = dlg:add_label(label_text, 1, 1, 1, 1)
	dlg:update()
end

callback=false
function input_callback(action)  -- action=add/del/toggle
	if (action=="toggle" and callback==false) then action="add"
	elseif (action=="toggle" and callback==true) then action="del" end

	local input = vlc.object.input()
	if input and callback==false and action=="add" then
		if Load_subtitles() then
			dlg:set_title("0/"..#subtitles.." Subtitler (lite)")
			if output_dialogbox==true then
				dialogbox_label("")
			end
			if output_osd==true then
				channel1 = vlc.osd.channel_register()
			end
			--
			callback=true
			vlc.var.add_callback(input, "intf-event", input_events_handler, "Hello world!")
		end
	elseif input and callback==true and action=="del" then
		callback=false
		vlc.var.del_callback(input, "intf-event", input_events_handler, "Hello world!")

		--w1:set_text(html1..welcome..html2)
		dlg:set_title("Subtitler (lite)")
		dialogbox_label(html1..welcome..html2)
	end
end

function Load_subtitles()
	if subtitles_path==nil then subtitles_path=media_path("srt") end
-- read file
	local file = io.open(subtitles_path, "r")
	if file==nil then return false end
	--data = file:read("*a")
	data = file:read(500000)
	file:close()
-- parse data
	subtitles={}
	srt_pattern = "(%d%d):(%d%d):(%d%d),(%d%d%d) %-%-> (%d%d):(%d%d):(%d%d),(%d%d%d).-\n(.-)\n\n"
	for h1, m1, s1, ms1, h2, m2, s2, ms2, text in string.gmatch(data, srt_pattern) do
		if text=="" then text=" " end
		if charset~=nil then text=vlc.strings.from_charset(charset, text) end
		table.insert(subtitles,{format_time(h1, m1, s1, ms1), format_time(h2, m2, s2, ms2), text})
	end
	if #subtitles~=0 then return true else return false end
end
function format_time(h,m,s,ms) -- time to seconds
	return tonumber(h)*3600+tonumber(m)*60+tonumber(s)+tonumber("."..ms)
end
function media_path(extension)
	local media_uri = vlc.input.item():uri()
	media_uri = vlc.strings.decode_uri(media_uri)
	media_uri = string.gsub(media_uri, "^.-///(.*)%..-$","%1")
	media_uri = media_uri.."."..extension
	vlc.msg.info(media_uri)
	return media_uri
end

-- SUBTITLING CORE:
subtitle=nil
function input_events_handler(var, old, new, data)
	local input = vlc.object.input()
	local actual_time = vlc.var.get(input, "time")
	
	if subtitle==nil then
		for i,v in pairs(subtitles) do
			if actual_time>=v[1] and actual_time<=v[2] then
--vlc.msg.info(actual_time.." << subtitle on")		
				subtitle=v
				dlg:set_title(i.."/"..#subtitles.." Subtitler (lite)")
				dlg:update()

				if output_dialogbox==true then
					osd_subtitle=string.gsub(subtitle[3],"\n","<br />")
					w1:set_text(html1..osd_subtitle..html2)
					dlg:update()
--vlc.msg.info(osd_subtitle)
				end
					--
				if output_osd==true then
					vlc.osd.message(subtitle[3],channel1,osd_position)
				end
				break
			end
		end
	else
		if actual_time<subtitle[1] or actual_time>subtitle[2] then
--vlc.msg.info(actual_time.." << subtitle off")		
			subtitle=nil
			if output_dialogbox==true then
				--w1:set_text("")
				dialogbox_label("")
			end
			if output_osd==true then
				vlc.osd.message("",channel1)
			end
		else
			if output_osd==true then
				vlc.osd.message(subtitle[3],channel1,osd_position) -- OSD subtitle refresh
			end
		end
	end
end
