#!/bin/sh
TITLE="Subtitler \(lite\) mod"
MSG="Pressing Enter key"
FLG=true

zenity --progress --pulsate --no-cancel --text="${MSG}" \
--title="${MSG}" &
SPID=$!

while true
do

if test `ps --pid ${SPID}|wc -l` -le 1; then
break
fi

xdotool search --name "${TITLE}" windowactivate
if test $? -eq 0 && $FLG; then
xdotool getactivewindow windowmove 0 0
FLG=false
fi

xdotool search --name "${TITLE}" key "Return"
if test $? -ne 0; then
kill ${SPID} 2>/dev/null
break
fi

sleep 1
done
