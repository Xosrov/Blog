Subtitler (lite)
VLC Extension
	
Submitted:  Jul 13 2012
Updated:  Nov 2 2014

Homepage: http://addons.videolan.org/content/show.php?content=152364	
Forum location: http://forum.videolan.org/viewtopic.php?f=29&t=97791


Description:
"Subtitler (lite) mod.lua" - A semiautomatic workaround for VLC-2.1+ with [Refresh] button in the dialog box that should be pressed periodically during playback. Just use it with some button presser / key sender (see USAGE below).
"Subtitler (lite).lua" - The extension works only in VLC-2.0.x. The automatic solution should not be forgotten. VLC archive: http://download.videolan.org/vlc/

Subtitler (lite) is VLC extension that displays subtitles on the screen in a playing video and/or in a dialog box. Now you can watch your film with 2 different subtitles. Subtitler (lite) mod now can SKIP unwanted scenes (intro, credits, commercials, unimportant scenes, ...) or MUTE selected scenes.

DOWNLOAD:
- click on the download button below
- save the .zip file
INSTALLATION:
- extract (unzip) the .lua file and put it in the VLC subdir /lua/extensions (create "extensions" directory if it does not exist there), by default:
* Windows (all users): %ProgramFiles%\VideoLAN\VLC\lua\extensions\
* Windows (current user): %APPDATA%\VLC\lua\extensions\
* Linux (all users): /usr/lib/vlc/lua/extensions/
* Linux (current user): ~/.local/share/vlc/lua/extensions/
* Mac OS X (all users): /Applications/VLC.app/Contents/MacOS/share/lua/extensions/
* Mac OS X (current user): /Users/%your_name%/Library/Application Support/org.videolan.vlc/lua/extensions/
Restart the VLC.
USAGE:
Then you simply start the extension by going to the "View" menu or "Vlc > Extensions" on Mac OS X and selecting it there.
The extension will try to load SRT subtitle file of the same name and location as a playing media ("d:\films\film.avi" --> "d:\films\film.srt").
Subtitler (lite) mod: Then you need to keep pressing the [Refresh] button in the dialog box. You rather use some button presser / key sender. Following ones are included in the package:
- "keypresser.vbs", a simple VBScript for Windows users;
- "buttonpresser.applescript", a simple AppleScript for Mac OS X users
http://addons.videolan.org/content/show.php?content=152364&forumpage=1#c473169
Is there any similar solution for Linux users?
AutoHotkey script:
https://forum.videolan.org/viewtopic.php?f=29&t=97791&start=40#p407066

To set up the Subtitler (lite), please edit global variables at the beginning of the script:
http://forum.videolan.org/viewtopic.php?f=29&t=97791#p346506
subtitles_uri = nil
The default value nil means, that the variable subtitles_uri is not defined and the script automatically looks for a SubRip (SRT) subtitle file of the same name and location as a playing media ("d:\films\film.avi" --> "d:\films\film.srt"). You can customize the "srt" extension in filename_extension variable (see below).
You can set your custom uri ("file:///D:/films/subtitles.srt"). A web browser can help you to encode a path in uri format (Firefox: open a file (drag&drop) in the browser, right-click, show info).
output_dialogbox = false
Set the value true or false. If it is true, then it displays subtitles in the dialog window.
output_osd = true
It displays subtitles in a playing video. If a video is not available (audio files), then it automatically displays subtitles (lyrics) in the dialog box.
osd_position = "top"
You can place subtitles in a playing video on "top", "top-left", "top-right", "left", "center", "right", "bottom", "bottom-left", "bottom-right".
charset = "Windows-1250"
Set an appropriate code page of your subtitle files (Western European subtitles "Windows-1252"). UTF-8 charset is automatically detected, but you can force it if you want. nil value also means "UTF-8" charset.
filename_extension = "srt"
You can set your custom extension for your subtitles dedicated to Subtitler. You can set a language code ("eng.srt") or you can set some other extension ("srt-vlc") as a subtitle file now can contain commands for Subtitler (lite) mod.
execute_commands = true
The default value executes commands [SKIP], [MUTE] found at the beginning of a subtitle text. You can use any subtitle editor with SRT support (Subtitle Edit http://www.nikse.dk/subtitleedit/ , Aegisub http://www.aegisub.org/ ) or just any ordinary text editor (Notepad) to create/edit SRT subtitles/scripts/cutlists for Subtitler (lite) mod.

Donation:
If you find this extension interesting, your donation is welcome at http://www.videolan.org/ to encourage developers to do some maintenance and improvements of Lua Extensions support in VLC.
https://trac.videolan.org/vlc/ticket/8097
https://trac.videolan.org/vlc/ticket/3883



Changelog:
Subtitler (lite) mod 1.2 (2.11.2014) 33650
- support for [SKIP] and [MUTE] commands at the beginning of subtitle text
- autodetection of UTF-8 charset of loaded subtitles
- different method of loading subtitles (URI) now should not have any problem to load subtitle files with paths containing also other than Basic Latin (non-ASCII) characters

Subtitler (lite) mod 1.1 (29.3.2014)
- a workaround for VLC-2.1+ with [Refresh] button in the dialog box that should be pressed periodically during playback. Some software button presser or key sender is recommended. A simple VBS script for Windows users is included in the package.

Subtitler (lite) 1.0 (13.7.2012)
- initial release based on vlc.var.add_callback() function removed since VLC-2.1


License: GPL


Subtitler (lite) mod.zip:
buttonpresser.applescript
keypresser.vbs
readme.txt
SRT with [SKIP], [MUTE] commands for Subtitler (lite) mod.srt-vlc
Subtitler (lite).lua
Subtitler (lite).png
Subtitler (lite) mod.lua
Subtitler (lite) mod.png